from .models import Book

def total_book_count(request):
    return {'total_books': Book.objects.count()}
