from django.db import models

class Book(models.Model):
    name = models.CharField(max_length=255)
    author = models.CharField(max_length=255)
    pages = models.IntegerField()
    condition = models.CharField(max_length=50)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    shelf_number = models.CharField(max_length=10)
    edition_number = models.CharField(max_length=50)
    image = models.ImageField(upload_to='book_images/')
    categories = models.CharField(max_length=255, blank=True, null=True)
    copies = models.IntegerField(default=1)
    date = models.DateField(blank=True, null=True)  # Allow null values

    def __str__(self):
        return self.name
