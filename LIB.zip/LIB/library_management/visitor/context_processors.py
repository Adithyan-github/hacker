from .models import Visitor

def total_visitor_count(request):
    total_visitors = Visitor.objects.count()
    return {
        'total_visitors': total_visitors
    }
