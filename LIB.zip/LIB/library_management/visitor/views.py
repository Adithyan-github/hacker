from django.shortcuts import render, redirect, get_object_or_404
from .models import Visitor
from .forms import VisitorForm

def visitor_list(request):
    search_date = request.GET.get('search_date')
    visitors = Visitor.objects.all()

    if search_date:
        visitors = visitors.filter(visit_date=search_date)

    return render(request, 'visitor/visitor_list.html', {
        'visitors': visitors,
        'search_date': search_date,
    })

def visitor_create(request):
    if request.method == 'POST':
        form = VisitorForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('visitor_list')
    else:
        form = VisitorForm()

    return render(request, 'visitor/visitor_form.html', {'form': form})

def visitor_edit(request, pk):
    visitor = get_object_or_404(Visitor, pk=pk)

    if request.method == 'POST':
        form = VisitorForm(request.POST, instance=visitor)
        if form.is_valid():
            form.save()
            return redirect('visitor_list')
    else:
        form = VisitorForm(instance=visitor)

    return render(request, 'visitor/visitor_form.html', {'form': form})

def visitor_delete(request, pk):
    visitor = get_object_or_404(Visitor, pk=pk)

    if request.method == 'POST':
        visitor.delete()
        return redirect('visitor_list')

    return render(request, 'visitor/visitor_confirm_delete.html', {'visitor': visitor})
