from django.db import models
from django.utils import timezone

class Visitor(models.Model):
    VISITOR_TYPE_CHOICES = [
        ('student', 'Student'),
        ('faculty', 'Faculty'),
        ('guest', 'Guest'),
    ]
    
    visitor_name = models.CharField(max_length=100)
    visitor_type = models.CharField(max_length=10, choices=VISITOR_TYPE_CHOICES)
    visitor_address = models.CharField(max_length=400)
    visitor_phonenumber = models.CharField(max_length=15)
    visit_date = models.DateField(default=timezone.now)  # Ensure the default is correct
    entry_time = models.TimeField()
    exit_time = models.TimeField()
    visitor_purpose = models.CharField(max_length=500)

    def __str__(self):
        return self.visitor_name
