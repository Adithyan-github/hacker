from django import forms
from .models import Visitor

class VisitorForm(forms.ModelForm):
    class Meta:
        model = Visitor
        fields = [
            'visitor_name', 
            'visitor_type', 
            'visitor_address', 
            'visitor_phonenumber', 
            'visit_date',
            'entry_time', 
            'exit_time', 
            'visitor_purpose'
        ]
        widgets = {
            'visit_date': forms.DateInput(attrs={'type': 'date'}), 
            'entry_time': forms.TimeInput(attrs={'type': 'time'}),
            'exit_time': forms.TimeInput(attrs={'type': 'time'}),
        }
