# visitor/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('', views.visitor_list, name='visitor_list'),
    path('add/', views.visitor_create, name='visitor_create'),
    path('edit/<int:pk>/', views.visitor_edit, name='visitor_edit'),
    path('delete/<int:pk>/', views.visitor_delete, name='visitor_delete'),
]
