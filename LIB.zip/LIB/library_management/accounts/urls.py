from django.urls import path
from . import views

urlpatterns = [
    path('profile/', views.profile, name='profile'),
    path('update-username/', views.update_username, name='update_username'),
    path('update-password/', views.update_password, name='update_password'),
    path('', views.user_login, name='login'),  # Add this line if not already present
    path('index/',views.index,name='index')
]
