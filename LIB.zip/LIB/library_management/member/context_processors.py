from .models import Member

def total_member_count(request):
    return {'total_members': Member.objects.count()}
