from django.db import models

class Member(models.Model):
    name = models.CharField(max_length=100)
    address = models.TextField()
    age = models.IntegerField()
    phone_number = models.CharField(max_length=15)

    def __str__(self):
        return self.name
    
class Sale(models.Model):
    member = models.ForeignKey(Member, on_delete=models.CASCADE)
    book_name = models.CharField(max_length=200)
    book_condition = models.CharField(max_length=100, default="Good")
    sell_date = models.DateField()
    return_date = models.DateField()

    def __str__(self):
        return f"{self.book_name} - {self.member.name}"
