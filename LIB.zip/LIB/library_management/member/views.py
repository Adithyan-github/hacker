# views.py
from django import forms
from django.shortcuts import render, get_object_or_404, redirect
from .models import Member, Sale
from .forms import MemberForm, SaleForm
from django.db.models import Q

def member_list(request):
    query = request.GET.get('search', '')
    members = Member.objects.filter(Q(name__icontains=query))
    return render(request, 'member/member_list.html', {'members': members})

def member_add(request):
    if request.method == 'POST':
        form = MemberForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('member_list')
    else:
        form = MemberForm()
    return render(request, 'member/member_form.html', {'form': form})

def member_edit(request, pk):
    member = get_object_or_404(Member, pk=pk)
    if request.method == 'POST':
        form = MemberForm(request.POST, instance=member)
        if form.is_valid():
            form.save()
            return redirect('member_list')
    else:
        form = MemberForm(instance=member)
    return render(request, 'member/member_form.html', {'form': form})

def member_delete(request, pk):
    member = get_object_or_404(Member, pk=pk)
    if request.method == 'POST':
        member.delete()
        return redirect('member_list')
    return render(request, 'member/member_confirm_delete.html', {'member': member})

def sale_list(request):
    query = request.GET.get('search', '')  # Get the search term from the query parameters
    if query:
        sales = Sale.objects.filter(member__phone_number__icontains=query)
        if not sales.exists():
            message = "No sales found."
        else:
            message = None
    else:
        sales = Sale.objects.all()
        message = None
    
    return render(request, 'member/sale_list.html', {'sales': sales, 'query': query, 'message': message})

def sale_add(request):
    form = SaleForm(request.POST or None)
    members = None

    if request.method == 'POST':
        phone_number = request.POST.get('phone_number')
        selected_member_id = request.POST.get('member')

        if 'search' in request.POST:
            # Search for members by phone number
            members = Member.objects.filter(phone_number=phone_number)
            if not members.exists():
                form.add_error('phone_number', 'Member not found')
            return render(request, 'member/sale_form.html', {'form': form, 'members': members})
        
        elif 'save' in request.POST:
            if selected_member_id:
                member = get_object_or_404(Member, pk=selected_member_id)
            else:
                member = Member.objects.filter(phone_number=phone_number).first()
            
            if member:
                sale = form.save(commit=False)
                sale.member = member  # Associate the selected member with the sale
                sale.save()
                return redirect('sale_list')
            else:
                form.add_error('phone_number', 'Member not found')
    
    return render(request, 'member/sale_form.html', {'form': form, 'members': members})

def sale_edit(request, pk):
    sale = get_object_or_404(Sale, pk=pk)
    member = sale.member  # Get the member associated with the sale

    if request.method == 'POST':
        form = SaleForm(request.POST, instance=sale)
        if form.is_valid():
            # Update the sale instance with the phone number of the existing member
            sale = form.save(commit=False)
            sale.member = member  # Ensure the sale's member remains unchanged
            sale.save()
            return redirect('sale_list')  # Redirect to the list page after saving
    else:
        form = SaleForm(instance=sale)
        # Set the phone number field's initial value to the current member's phone number
        form.fields['phone_number'].initial = member.phone_number

    return render(request, 'member/sale_edit.html', {'form': form, 'sale': sale})


def sale_delete(request, pk):
    sale = get_object_or_404(Sale, pk=pk)
    if request.method == 'POST':
        sale.delete()
        return redirect('sale_list')
    return render(request, 'member/sale_confirm_delete.html', {'sale': sale})