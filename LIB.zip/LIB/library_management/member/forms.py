from django import forms
from .models import Member, Sale

class MemberForm(forms.ModelForm):
    class Meta:
        model = Member
        fields = ['name', 'address', 'age', 'phone_number']

class SaleForm(forms.ModelForm):
    phone_number = forms.CharField(max_length=15, required=True, label='Phone Number', widget=forms.TextInput(attrs={'readonly': 'readonly'}))

    class Meta:
        model = Sale
        fields = ['phone_number', 'book_name', 'book_condition', 'sell_date', 'return_date']
        widgets = {
            'sell_date': forms.DateInput(attrs={'type': 'date'}),
            'return_date': forms.DateInput(attrs={'type': 'date'}),
        }